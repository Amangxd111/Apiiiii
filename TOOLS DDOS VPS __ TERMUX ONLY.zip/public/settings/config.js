global.creator = "@bebas"
global.token = "TOKEN BOT"
global.chatid = "USER ID"
global.watermark = "© bebas"
